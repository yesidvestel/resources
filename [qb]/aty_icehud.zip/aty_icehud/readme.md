## Usage
- Set you framework from config. If you set the framework to "standalone" hunger, thirst and money will not be shown
- I added notes to the files so you can modify it easily
- You need to change the logo from "ui/img"
- I used scss but you can use normal css
- You can move or customize the minimap from "stream/minimap.gfx" with right tools

## Features
- Status hud (Standalone, QBCore or ESX) 
- Carhud (Speedometer, seatbelt, cruise control, fuel level and engine health) 
- Stats (Right Top) (Logo, id, ping and money)
- Easily customizable

## Help
- If you need any help contact me through Discord: https://discord.gg/eUDGHx5Kbt. Or dm me: atiysu#6666
