fx_version 'cerulean'
game 'gta5'


loadscreen 'web/ui.html'
-- loadscreen_manual_shutdown 'yes'
loadscreen_cursor 'yes'

-- ui_page 'web/ui.html'



files {
    "web/**/*",
    "web/**",
    "web/*",

}