Citizen.CreateThread(function()
    AddTextEntry('0x42E65228','CallSign - 0')   -- NKB_A0
    AddTextEntry('0x56747944','CallSign - 1')   -- NKB_A1
    AddTextEntry('0xF0C62DE5','CallSign - 2')   -- NKB_A2
    AddTextEntry('0xBE7B4950','CallSign - 3')   -- NKB_A3
    AddTextEntry('0x0BF4E442','CallSign - 4')   -- NKB_A4
    AddTextEntry('0xDBBF03D7','CallSign - 5')   -- NKB_A5
    AddTextEntry('0xB978BF4B','CallSign - 6')   -- NKB_A6
    AddTextEntry('0x8673D94E','CallSign - 7')   -- NKB_A7
    AddTextEntry('0xD4ED7634','CallSign - 8')   -- NKB_A8
    AddTextEntry('0xD4ED7634','CallSign - 9')   -- NKB_A8

    AddTextEntry('0xC4B36000','CallSign - 0')   -- NKB_B0
    AddTextEntry('0xB732C4FF','CallSign - 1')   -- NKB_B1
    AddTextEntry('0xB24FBB39','CallSign - 2')   -- NKB_B2
    AddTextEntry('0xA4701F7A','CallSign - 3')   -- NKB_B3
    AddTextEntry('0x0F92F5BE','CallSign - 4')   -- NKB_B4
    AddTextEntry('0xFFCC5631','CallSign - 5')   -- NKB_B5
    AddTextEntry('0xDAD50C43','CallSign - 6')   -- NKB_B6
    AddTextEntry('0x454AE131','CallSign - 7')   -- NKB_B7
    AddTextEntry('0x3868476C','CallSign - 8')   -- NKB_B8
    AddTextEntry('0x32A63BE8','CallSign - 9')   -- NKB_B9

    AddTextEntry('0xC98F6AD8','CallSign - 0')   -- NKB_C0
    AddTextEntry('0xBB5DCE75','CallSign - 1')   -- NKB_C1
    AddTextEntry('0xA7B2A71F','CallSign - 2')   -- NKB_C2
    AddTextEntry('0x11827ABD','CallSign - 3')   -- NKB_C3
    AddTextEntry('0x002CD812','CallSign - 4')   -- NKB_C4
    AddTextEntry('0xEDE6B386','CallSign - 5')   -- NKB_C5
    AddTextEntry('0xDEBA152D','CallSign - 6')   -- NKB_C6
    AddTextEntry('0x4857E86B','CallSign - 7')   -- NKB_C7
    AddTextEntry('0x3B244E04','CallSign - 8')   -- NKB_C8
    AddTextEntry('0x24EA2190','CallSign - 9')   -- NKB_C9

    AddTextEntry('0x7F64C267','Antenna - 1')   -- NKB_ANTENNA_1
    AddTextEntry('0xCC505C3D','Antenna - 2')   -- NKB_ANTENNA_2
    AddTextEntry('0xDA84F8A6','Antenna - 3')   -- NKB_ANTENNA_3
    AddTextEntry('0x7C6CBC77','Antenna - 4')   -- NKB_ANTENNA_4
    AddTextEntry('0x4A88D8B0','Antenna - 5')   -- NKB_ANTENNA_5

    AddTextEntry('0xBD85CD1D','Default Bumper')   -- NKB_RAM_1

    AddTextEntry('0x2C5A3D0F','Police Painting')   -- NKB_LIVERY1
end)