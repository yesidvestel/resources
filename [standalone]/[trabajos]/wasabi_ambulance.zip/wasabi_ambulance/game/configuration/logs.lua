-----------------For support, scripts, and more----------------
--------------- https://discord.gg/wasabiscripts  -------------
---------------------------------------------------------------

SConfig = {
    deathLogs = {
        webhook = 'https://discord.com/api/webhooks/1274264386663612416/ukj25eU7qPaGPO-J1Z0fv-y5_XLDuAdncg6Uj26ZUdtHhJEMJqovV48EhhznrmZLdqvK', -- Change to discord webhook / must have Config.DeathLogs enabled
        color = 15548997 -- Default: 15548997 (Red) - https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
    },
    reviveLogs = {
        webhook = 'https://discord.com/api/webhooks/1274264744194342922/NI_3OZZgi6gE5dZWQcXuZofkftqFRp6AlNmTiSbODhzNxXfe0khQLV_bwO306ckTh2oy', -- Change to discord webhook / must have Config.ReviveLogs enabled
        color = 15548997 -- Default: 15548997 (Red) - https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
    },
}
